# PonziPedia
PonziPedia - Peer 2 Peer 50% ROI Donation System script
<div data-view="toggleItemDescription">
        <div class="js-item-description item-description has-toggle">
          <div class="user-html"><p><strong><a href="http://ponzipedia.ml" rel="nofollow">PonziPedia</a></strong> - Peer 2 Peer 50% ROI Donation System script, PonziPedia is the best way to start your own pair 2 pair donation website!<br>
PonziPedia is fast, secured, and it will be regularly updated.<br>
</p><blockquote>PonziPedia initial release v1.5</blockquote>
<blockquote>Check out the complete features online <a href="http://ponzipedia.ml" rel="nofollow">Online Demo</a>
</blockquote>
<blockquote>2 Support System included!</blockquote><br><br>
<img src="https://ponzipedia.ml/images/gradient-bg-Recovered.jpg">
<img src="https://ponzipedia.ml/images/desc-main-Recoveredko.png">
<img src="https://ponzipedia.ml/images/image7.png">
<a href="https://ponzipedia.ml" rel="nofollow"><img src="https://ponzipedia.ml/images/image101.png"></a><br><br>
PonziPedia is very easy to install, <a href="https://www.youtube.com/watch?v=s5qvuuOrhBk" rel="nofollow">Watch how to install PonziPedia</a><br> Online Documentation <a href="http://docs.maylancer.cf">Installation Guides</a><br>
<br>
<h2 id="item-description__user-features-demo">User Features  (<a href="https://ponzipedia.ml" rel="nofollow">Demo</a>)</h2>
<ul>
  <li>
<strong>High Level Cache System:</strong> The #1 thing that must be available on any high traffic website, The Speed ! We Speed up your website with our Cache system</li>
  <li>
<strong>PonziPedia (New Feature)</strong>: With our new feature, user can create tickets, messages, comments.</li>
  <li>
<strong>System join</strong>: Easy to Registrared & Login.</li>
  <li>
<strong>Account revovery</strong>: Instant Work Forgot Password & secure password with salt.</li>
  <li>
<strong>Easy &amp; Notofication:</strong> Support email Notification on all user activities.</li>
  <li>
<strong>Periodic Margin </strong>: Fully Automated Matching System.</li>
<li><strong>POF Upload </strong>: Payment proof uplaod by all members after payment.</li>
<li><strong>Activation Fees System</strong>: New members will pay activations fees for account activation.</li>
<li><strong>Notification System</strong>: Display live members activities with our notification system.</li>
<li><strong>User Profit </strong>: Easy to Donate Someone and get paid autmatically Periodic.</li>
<li><strong>User Dashboard</strong>: Informative User Dashboard.</li>
<li><strong>User testimony</strong>: Live member testimony with like and dislike system reactions.</li>
<li><strong>Bank System</strong>: Auto Generate user Account Number And Balance System</li>
<li><strong>Be Informed</strong>: Displays Notice Board to all users</li>
 <li>
<strong>Full Authentication</strong>: The script provides the complete functionality for authentication: Log in, Sign up, Email Activation and Password Recover.</li>
 <li>
<strong>Get Support</strong>: Fully responsive support system in-built live message and tickets support</li>
 <li>
<strong>Message System</strong>: Fully responsive support message system live chatting In-Built</li>
    <li>
<strong>Court Case</strong>: Ability to drag member to case if failure to pay or fake POF</li>
  <li>
<strong>Duscussion</strong>: User can create interact with comments on in-built discussion board.</li>
  <li>Fully responsive for all devices, browsers.</li>
  <li>Password recovery by email.</li>
  <li>Comment auto detector (Moderated)</li>
</ul>
<h5 id="item-description__and-much-more"><em>and much more…</em></h5>
<h2 id="item-description__admin-panel-features">Admin Panel Features:</h2>
<ul>
  <li>
<strong>Admin Dashboard</strong>: Full statics with charts analyzing the site information.</li> 
  <li>
<strong>General Settings</strong>: Update general settings of website.</li>
  <li>
<strong>Site settings</strong>: Update site settings like name,title,keywords.. etc ..</li>
  <li>
<strong>Create Packages</strong>: Create packages for user to purchase on the website.</li>
  <li>
<strong>Activation Fees System</strong>: You can make profit with activation fees system & its optional can be switch off by you</li>
  <li>
<strong>Support System</strong>: Full responsive support system, reply live message or user tickets easily</li>
  <li>
<strong>Manage Users</strong>: View, edit, verify, reset password, delete users.</li>
  <li>
<strong>Manage Margin</strong>: View, disengage margin easily.</li>
  <li>
<strong>Add/Edit Margin</strong>: Add and edit margin on easy way from the admin panel.</li>
  <li>
<strong>Mailing List</strong>: With our mailing list system you can send your message to all registered users/subscribers in just one click !</li>
  <li>
<strong>Full Authentication</strong>: The script provides the complete functionality for authentication: Log in, Sign up, Email Activation and Password Recover.</li>
  <li>
<strong>Security </strong>: The script uses Bcrypt for password hashing, encrypted cookies, XSS and CSRF attack preventions. </li>
  <li>
<strong>Ban user</strong>: Ben user ip on very easy way.</li>
  <li>
<strong>reCaptcha</strong>: Add, edit your reCaptcha key.</li>
<li>
<strong>Quick Start + In Depth Documentation</strong>: Install and configure the script in matter of minutes or read the in depth documentation to learn more about the script.</li>
</ul>
<h5 id="item-description__and-so-much-more"><em>and so much more…</em></h5>
<h2 id="item-description__requirements">Requirements:</h2>
PHP 5.5 or Higher.<br>
MCrypt<br>
PDO MYSQL.<br>
OpenSSL<br>
GD.<br>
Exif (optional)<br>
Multibyte String (optional)<br>
Internationalization (optional)<br>
<br>
<h2 id="item-description__native-applications-for-PonziPedia">Support Facility:</h2>
<blockquote>
  Please send us your product presale query, after sales developer support request, customization request and any other queries to support: 
</blockquote>
<a href="https://facebook.com/olakunlevpn" rel="nofollow">Contact Me Here</a><br>
<h2 id="item-description__updates">Updates</h2>
 <h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.5 </strong> 05/02/2018</h5>
<blockquote>
<li> Added: Member Court Case</li>
<li> Added: Support Tickets System</li>
<li> Improved: Website speed with 99%</li>
<li> Fixed: Reported Bugs..</li>
<li> & much more...</li>
</blockquote>
 <h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.4 </strong> 04/28/2018</h5>
<blockquote>
<li> Added: Member payment Logs</li>
<li> Improved: Admin Panel Core Settings</li>
<li> Fixed: Reported Bugs..</li>
<li> & much more...</li>
</blockquote>
<h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.3 </strong> 04/20/2018</h5>
<blockquote>
<li> Added: Member Testimony like/dislike Reactions</li>
<li> Improved: Force Testimony Before Payment Confirmation </li>
<li> Added: Real Live Support Chats In-Built Support</li>
<li> Improved: Admin Panel live chats</li>
<li> Fixed: Some Bugs..</li>
<li> & much more...</li>
</blockquote>
 <h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.2 </strong> 04/20/2018</h5>
<blockquote>
<li> Added: Member Testimony system</li>
<li> Added: Force Testimony Before Payment Confirmation</li>
<li> Added: Email Notification on members activities</li>
<li> Improved: Admin Panel</li>
<li> Improved: Website Design</li>
<li> Improved: FrontEnd Design</li>
<li> Fixed: Some Bugs..</li>
<li> & much more...</li>
</blockquote>
<h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.1 </strong> 03/12/2018</h5>
<blockquote>
<li> Added: Activation Fees system</li>
<li> Added: Invitation Codes (Open/Close Registration)</li>
<li> Added: Automatic Margin system</li>
<li> Added: Referral system</li>
 <li> Added: Guider Members system</li>
<li> Fixed: All Reported Bugs</li>
<li> Improved: Website speed with 99%</li>
</blockquote>
<h5 id="item-description__version-1-5-5-2-04-06-2018">
<strong>Version 1.0 </strong> 01/08/2018</h5>
<blockquote>
<li> Initial Release</li>
</blockquote>

</blockquote><br></div>
        </div>
      
