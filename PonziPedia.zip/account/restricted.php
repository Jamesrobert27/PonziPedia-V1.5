<?php

require_once '../app/init.php';

?>
<head>
	
<title>Access Denied</title>

	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</head>
<body>
	
<div class="container">
	
	<div class="jumbotron">
	 <h2 class="text-center" style="color:red">You didn't have access to view this page<br>

</h2>
    </div>
   <center><img src="<?php echo asset_url('img/avatar-56f3a45e06.gif') ?>"></center> 
</div>    
    
</div>
</body> 