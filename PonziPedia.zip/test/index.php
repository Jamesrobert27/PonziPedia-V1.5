<?php

header("location: ../");

?>