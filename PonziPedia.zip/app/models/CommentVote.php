<?php

class CommentVote extends Model {

	protected $table = 'commentvotes';

	protected $guarded = array('id');
}