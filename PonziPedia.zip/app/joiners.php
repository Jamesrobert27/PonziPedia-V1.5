<?php


require_once  'functions.php'; 
require_once  'function2.php'; 
require_once  'function3.php'; 
require_once  'function4.php'; 
require_once  'settings.class.php'; 
require_once  'Extra.class.php';
require_once  'ImageManipulator.php';
?>